const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  fname: {
    type: String,
    trim: true,
    required: "First Name is required",
  },
  lname:{
    type:String,
    trim:true,
    required:"Last Name is required",
    unique:true 
  },
  email: {
    type: String,
    trim: true,
    lowercase: true,
    unique: true,
    required: "Email address is required",
  },
  password: {
    type: String,
    required: "password is required",
  },
  mobile: {
    type: String,
    required: "number is required",
  },
  house: {
    type: String,
    required: "house number is required",
  },
  role: {
    type: String
  },
  credit:{
    type:Number,
    trim:true,
    default:0
  },
  debit: {
    type: Number,
    trim: true,
    default:0
  },
  interest:{
    type:Number,
    trim:true,
    default:0
  },
  totalAmount: {
    type: Number,
    trim: true,
    default:0
  },
},{ timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } }
);

module.exports = mongoose.model("User", userSchema);
